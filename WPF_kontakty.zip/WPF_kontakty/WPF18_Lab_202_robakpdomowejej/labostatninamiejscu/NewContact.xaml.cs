﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Controls;
using System.Globalization;

namespace labostatninamiejscu
{
    /// <summary>
    /// Interaction logic for NewContact.xaml
    /// </summary>
    public partial class NewContact : Window
    {
        public MainWindow p;
        public string name;
        public class textvalue
        {
            public string Text { get; set; }
            public int filtr{get;set;}
        }
        public NewContact(MainWindow pp)
        {
            InitializeComponent();
            this.DataContext = this;
            textvalue namee = new textvalue();
            textvalue surnamee = new textvalue();
            textvalue Emailee = new textvalue();
            textvalue Phonee = new textvalue();
            p = pp;
            namee.filtr = p.cbName.SelectedIndex;
            surnamee.filtr = p.cbSurname.SelectedIndex;
            Emailee.filtr = p.cbEmali.SelectedIndex;
            Phonee.filtr = p.cbPhone.SelectedIndex;
            Namee.DataContext = namee;
            Surname.DataContext = surnamee;
            Emaile.DataContext = Emailee;
            Phone.DataContext = Phonee;
        }

        private void close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void add_Click(object sender, RoutedEventArgs e)
        {
            if (Namee.Foreground == Brushes.Red) return;
            if (Surname.Foreground == Brushes.Red) return;
            if (Phone.Foreground == Brushes.Red) return;
            if (Emaile.Foreground == Brushes.Red) return;
            if (Genderr.SelectedIndex==1)
                p.addNewperson(Namee.Text, Surname.Text, Emaile.Text, Phone.Text, labostatninamiejscu.Gender.Female);
            else
                p.addNewperson(Namee.Text, Surname.Text, Emaile.Text, Phone.Text, labostatninamiejscu.Gender.Male);
            this.Close();
        }

        private void tbFirstName_Error(object sender, ValidationErrorEventArgs e)
        {

        }
    }

    public class morethenfive : ValidationRule
    {
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            if (((string)value).Length < 5) return new ValidationResult(false, "5 or more signs");
            return ValidationResult.ValidResult;
        }
    }

    public class Wrapper : DependencyObject
    {
        public static readonly DependencyProperty filtrProperty =DependencyProperty.Register("filtr", typeof(int),typeof(Wrapper), new FrameworkPropertyMetadata(int.MaxValue));

        public int filtr
        {
            get { return (int)GetValue(filtrProperty); }
            set { SetValue(filtrProperty, value); }
        }
    }

    public class Validationoverrule : ValidationRule
    {
        public Validationoverrule()
        {
            what = 0;
        }

        public int what { get; set; }
        public MainWindow p { get; set; }

        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            string checke = ((string)value);
            int size = ((string)value).Length;


            if(size < 5&& this.Wrapper.filtr==0)
            {
                return new ValidationResult(false, $"Value must have at least 5 characters!!!");
            }
            if (this.Wrapper.filtr == 1)
            {
                if(!checke.Contains("@")) return new ValidationResult(false, $"Not Email!!!");
            }
            if (this.Wrapper.filtr == 2)
            {
                string pattern = @"^\d{4}-\d{4}-\d{4}$";
                if(!System.Text.RegularExpressions.Regex.IsMatch(checke, pattern, System.Text.RegularExpressions.RegexOptions.IgnoreCase)) return new ValidationResult(false, $"Not Phone xxxx-xxxx-xxxx!!!");
            }
            return ValidationResult.ValidResult;
        }
        public Wrapper Wrapper { get; set; }
    }


    
public class BindingProxy : System.Windows.Freezable
  {
    protected override Freezable CreateInstanceCore() {
      return new BindingProxy();
    }
 
    public object Data {
      get { return (object)GetValue(DataProperty); }
      set { SetValue(DataProperty, value); }
    }
 
    public static readonly DependencyProperty DataProperty =
        DependencyProperty.Register("Data", typeof(object), typeof(BindingProxy), new PropertyMetadata(null));
  }


}
