﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using Microsoft.Win32;

namespace labostatninamiejscu
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary> 
    class imageconverter : IValueConverter
    {

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if ((Gender)value == Gender.Male) return AppDomain.CurrentDomain.BaseDirectory + @"man.png";
            return AppDomain.CurrentDomain.BaseDirectory + @"woman.jpg";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    class visibilityconverterlocked : IValueConverter
    {
        object IValueConverter.Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if ((bool)value == true)
            {
                return "Visible";
            }
            return "Hidden";
        }

        object IValueConverter.ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    class visibilityconverterunlocked : IValueConverter
    {
        object IValueConverter.Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if ((bool)value != true)
            {
                return "Visible";
            }
            return "Hidden";
        }

        object IValueConverter.ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    public partial class MainWindow : Window
    {
        ObservableCollection<Person> people;
        bool vsislocked=true;
        public MainWindow()
        {
            InitializeComponent();
            vsislocked = true;
            people = new ObservableCollection<Person>();
            people.Add(new Person());
            people.Add(new Person());
            people.Add(new Person());
            people.Add(new Person());
            people.Add(new Person());
            people.Add(new Person());
            this.DataContext = people;
            lockgrid.DataContext = vsislocked;
            unlockgrid.DataContext = vsislocked;
        }

        public void addNewperson(string cname, string cSuranme, string cemali, string chonenumber,Gender gender)
        {
            people.Add(new Person(cname, cSuranme, cemali, chonenumber,gender));
        }
        private void about_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("This is simple contact manager", "Contact manager", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void MenuItemExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            NewContact contactn = new NewContact(this);
            contactn.ShowDialog();
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            people.Clear();
        }

        private void MenuItem_Export(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.DefaultExt = "xml";
            saveFileDialog.AddExtension = true;
            saveFileDialog.FileName = "Contacts";

            if ((bool)saveFileDialog.ShowDialog())
            {
                XmlSerializer serializer = new XmlSerializer(typeof(ObservableCollection<Person>));
                Stream fs = new FileStream(saveFileDialog.FileName, FileMode.OpenOrCreate);
                XmlWriter writer =
                new XmlTextWriter(fs, Encoding.Unicode);
                // Serialize using the XmlTextWriter.
                serializer.Serialize(writer, people);
                writer.Close();
            }
        }

        private void MenuItem_Import(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "xml files(*.xml)| *.xml";

            if ((bool)openFileDialog.ShowDialog())
            {
                XmlSerializer serializer = new XmlSerializer(typeof(ObservableCollection<Person>));
                string fmane = openFileDialog.FileName;
                Stream fs = new FileStream(openFileDialog.FileName,FileMode.Open);
                // Serialize using the XmlTextWriter.
                people.Clear();
                people = (ObservableCollection<Person>)serializer.Deserialize(fs);
                this.DataContext = people;
            }
        }
        private void Deletehiglighted_Click(object sender, RoutedEventArgs e)
        {
            if (Listakontaktow.SelectedItem != null)
                people.Remove((Person)Listakontaktow.SelectedItem);
        }

        private void unlockbutton_Click(object sender, RoutedEventArgs e)
        {
            vsislocked = false;
            lockgrid.DataContext = vsislocked;
            unlockgrid.DataContext = vsislocked;
        }

        private void lockvs_Click(object sender, RoutedEventArgs e)
        {
            vsislocked = true;
            lockgrid.DataContext = vsislocked;
            unlockgrid.DataContext = vsislocked;
        }
    }
    public enum Gender { Male, Female }
    public class Person
    {
        [XmlElement]
        public string Name { get; set; }
        [XmlElement]
        public string Surname { get; set; }
        [XmlElement]
        public string email { get; set; }
        [XmlElement]
        public string phonenumber { get; set; }
        [XmlElement]
        public Gender gender { get; set; }
        public Person()
        {
            Name = "Noname";
            Surname = "Nosurname";

        }

        public Person(string cname, string cSuranme, string cemali, string chonenumber, Gender ggender)
        {
            Name = cname;
            Surname = cSuranme;
            email = cemali;
            phonenumber = chonenumber;
            gender = ggender;
        }

    }

}
